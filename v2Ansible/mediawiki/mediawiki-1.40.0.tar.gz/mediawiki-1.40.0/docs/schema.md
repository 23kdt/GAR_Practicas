Schema
======

The most up-to-date schema for the tables in the database
will always be `tables.sql` in the maintenance directory,
which is called from the installation script.

That file has been commented with details of the usage for
each table and field.

Historical information and some other notes are available at
<https://www.mediawiki.org/wiki/Manual:Database_layout>.
